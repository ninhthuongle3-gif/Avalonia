LAST LIGHT / 最后灯火 — v0.2
30 骨骼动作与丧尸生存原型 / Windows 64 位

完整解压 ZIP，再双击 LastLight.exe。无需安装 Godot。
LastLight.exe 和 LastLight.pck 必须保留在同一个文件夹。
窗口标题应显示 v0.2；按 Enter 开始默认的三波丧尸生存模式。

操作：
WASD：自由移动，角色朝移动方向转身；鼠标：独立转动镜头。
Shift：冲刺；Space：跳跃。
按住鼠标右键：举枪瞄准，移动变慢并显示准星。
瞄准完成后按左键：自动射击。自由状态不会开火。
Q：左右换肩；R：换弹。
T：重开当前模式，恢复生命和弹药。
F2：切换三波丧尸生存 / 六靶训练。
F3：显示/隐藏真实骨骼的关节标记。
Esc：暂停、释放鼠标；Enter 或 Esc：恢复。
死亡或通关后按 Enter 重开；M：静音。

本次修改：
- 脚步按实际位移推进，支撑脚世界锁定和腿部 IK，减小滑步。
- 行走与冲刺有加速、刹车惯性、躯干前倾和步幅变化。
- 真正的 30 骨骼 Skeleton3D，四肢 IK、手指、脊柱、马尾、衣摆。
- 自由状态放低枪、无准星；右键逐渐举枪并进入慢步瞄准。
- 丧尸会巡逻、通过视线与枪声发现玩家、绕掩体追击、蓄力攻击。
- 身体三枪、爆头一枪击杀；受击可打断攻击。可通过移位躲开攻击前摇。
- 三波共 4 / 6 / 8 只，后续混入奔跑者，波次开始补充备用弹药。

这是程序化占位模型与动作原型，不含正式美少女模型、动捕、剧情、联机或存档。
需要支持 OpenGL 3.3 的桌面显卡和键盘鼠标，不是安卓或浏览器版本。
本次导出的游戏资源包接受 90 项 3D 逻辑与动作检查；没有 Windows 实机测试。
Godot 4.6.3；许可见 GODOT-LICENSES.txt 和 FONT-LICENSE.txt。

Unzip the entire archive and run LastLight.exe. Press Enter to start.
Hold RMB to raise the weapon; LMB fires only when aiming is ready.
F2 switches zombie survival / training. F3 shows skeleton joints.
