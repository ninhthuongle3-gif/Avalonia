LAST LIGHT / 最后灯火 — 第一阶段跨肩射击靶场

Windows 64 位试玩版
1. 完整解压此 ZIP 到一个文件夹。
2. 双击 LastLight.exe 启动，无需安装 Godot。
3. LastLight.exe 和 LastLight.pck 必须保留在同一个文件夹。
4. 按 Enter 开始。

操作：
WASD：移动；Shift：向前冲刺；Space：跳跃。
鼠标：转动视角；右键：瞄准；左键：自动射击。
Q：左右换肩；R：换弹；T：重置训练和补充弹药。
Esc：暂停并释放鼠标；Enter 或 Esc：恢复；M：静音。

目标：击倒六个不同靶标，其中一个移动靶。身体三枪、头部一枪击倒。
靶标会自动复位；重复击倒同一靶标不会增加独立目标计数。
镜头能看见目标时，枪口仍可能被掩体挡住。

本版本为手感原型：角色与动作是占位内容，没有丧尸 AI、剧情、联机或存档。
需要支持 OpenGL 3.3 的桌面显卡与键盘鼠标；此包不是安卓或浏览器版本。
由 Godot 4.6.3 导出。许可见 GODOT-LICENSES.txt 和 FONT-LICENSE.txt。

Unzip the complete archive, then run LastLight.exe.
Keep LastLight.exe and LastLight.pck together. Press Enter to start.
